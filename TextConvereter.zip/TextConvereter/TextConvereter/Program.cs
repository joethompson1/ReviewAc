﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.IO;
using System.Collections.Generic;

namespace TextConvereter
{
    class Program
    {
        static void Main(string[] args)
        {
            //loadText("inputFile.txt");
            //saveText("outputFile.txt");
            loadText("Alselm.txt");
            saveText("AlselmOut.txt");
            loadText("Ashburne.txt");
            saveText("AshburneOut.txt");
            loadText("Buckhardt.txt");
            saveText("BuckhardtOut.txt");
            loadText("Canterbury.txt");
            saveText("CanterburyOut.txt");
            loadText("Dalton-Ellis.txt");
            saveText("Dalton-EllisOut.txt");
            loadText("Denmark.txt");
            saveText("DenmarkOut.txt");
            loadText("Gabriel.txt");
            saveText("GabrielOut.txt");
            loadText("George.txt");
            saveText("GeorgeOut.txt");
            loadText("Horniman.txt");
            saveText("HornimanOut.txt");
            loadText("Hulme.txt");
            saveText("HulmeOut.txt");
            loadText("LibertyPark.txt");
            saveText("LibertyParkOut.txt");
            loadText("LibertyPoint.txt");
            saveText("LibertyPointOut.txt");
            loadText("ManchesterGardens.txt");
            saveText("ManchesterGardensOut.txt");
            loadText("Oak.txt");
            saveText("OakOut.txt");
            loadText("Owens.txt");
            saveText("OwensOut.txt");
            loadText("Richmond.txt");
            saveText("RichmondOut.txt");
            loadText("Sheavyn.txt");
            saveText("SheavynOut.txt");
            loadText("Weston.txt");
            saveText("WestonOut.txt");
            loadText("Whitworth.txt");
            saveText("WhitworthOut.txt");
            loadText("Woolton.txt");
            saveText("WooltonOut.txt");
            loadText("Wright.txt");
            saveText("WrightOut.txt");
        }

        public static string[][] parseArray = new string[8][];
        //Name, {postcode}, occupancy, studentType[], roomtype[], weeks[],
        //priceyear[], priceweek[]

        public static void saveText(string filename)
        {
            using (StreamWriter writer = new StreamWriter(filename))
            {
                writer.WriteLine("--------START OF ACCOMMODATION--------");
                int count = 0;
                foreach (string multidata in parseArray[5])
                {
                    writer.WriteLine("------------Start of Room------------");
                    string outputString = "";
                    for (int index = 0; index < 4; index++)
                    {
                        outputString = parseArray[index][0];
                        outputString = outputString.Trim('%');
                        writer.WriteLine(outputString);
                    }
                    for (int index = 4; index < 8; index++)
                    {
                        outputString = parseArray[index][count];
                        writer.WriteLine(outputString);
                    }
                    count++;
                    writer.WriteLine("-------------End of Room-------------");
                }
                writer.WriteLine("---------END OF ACCOMMODATION---------");
            }
        }

        public static void loadText(string filename)
        {
            using (StreamReader reader = new StreamReader(filename))
            {
                string line;
                string[] tempArray1 = new string[1]; //array to input into parseArray
                
                //postcode
                string postcode = "TEMP";
                line = reader.ReadLine();
                postcode = line;
                //postcode goes on top

                line = reader.ReadLine(); //read next line
                tempArray1[0] = line; //name is 1 line
                parseArray[0] = (string[])tempArray1.Clone(); //NAME


                
                tempArray1[0] = postcode; //postcode is entered manually above
                parseArray[1] = (string[])tempArray1.Clone(); //POSTCODE

                line = reader.ReadLine(); //[factsheet]
                line = reader.ReadLine(); //[Occupancy]

                line = reader.ReadLine(); //OCCUPANCY
                tempArray1[0] = line;
                parseArray[2] = (string[])tempArray1.Clone(); //OCCUPANCY

                line = reader.ReadLine(); //[studenttype]

                string stType = "";
                line = reader.ReadLine();
                while ((line == "Undergraduate") || (line == "Postgraduate")) //STUDENTTYPE
                {
                    stType += line + "/";
                    line = reader.ReadLine();
                }
                stType = stType.Trim('/');
                tempArray1[0] = stType;
                parseArray[3] = (string[])tempArray1.Clone(); //STUDENTTYPE

                //line = reader.ReadLine(); //[price] \t [from] \s PRICE
                //removed for while loop
                line = reader.ReadLine(); //campus
                line = reader.ReadLine(); //[bathroom]
                line = reader.ReadLine(); //bathroom
                line = reader.ReadLine(); //[catering]
                line = reader.ReadLine(); //catering
                line = reader.ReadLine(); //website
                line = reader.ReadLine(); //[costs]
                line = reader.ReadLine(); //[accom, costs..]

                
                string roomtype = "";
                string weeks = "";
                string pricetotal = "";
                string priceweek = "";
                while ((line = reader.ReadLine()) != null)
                {
                    //ROOMTYPE \t WEEKS \t PRICETOTAL \t PRICEWEEK * n
                    string[] tempArray3 = line.Split('\t');
                    roomtype += tempArray3[0] + "%"; 
                    weeks += tempArray3[1] + "%";
                    pricetotal += tempArray3[2];
                    priceweek += tempArray3[3];

                }
                roomtype = roomtype.Trim('%');
                weeks = weeks.Trim('%');
                pricetotal = pricetotal.Trim('£');
                priceweek = priceweek.Trim('£');
                string[] roomtypeArray = roomtype.Split('%');
                string[] weeksArray = weeks.Split('%');
                string[] pricetotalArray = pricetotal.Split('£');
                string[] priceWeekArray = priceweek.Split('£');

                parseArray[4] = (string[])roomtypeArray.Clone();

                parseArray[5] = (string[])weeksArray.Clone();

                parseArray[6] = (string[])priceWeekArray.Clone();

                parseArray[7] = (string[])pricetotalArray.Clone();



            }
        }

    }
}
